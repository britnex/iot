package main

import (
	"bufio"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"os"
	"regexp"
	"strconv"
	"strings"
)

func reversebytearr(arr []byte) []byte {
	l := len(arr)
	ret := make([]byte, l)
	for i := l - 1; i >= 0; i-- {
		ret[i] = arr[l-1-i]
	}
	return ret
}

type Gateway struct {
	IfaceName   string
	Gateway     net.IP
	Destination net.IP
	Metric      uint32
}

type Gateways struct {
	Gateways []Gateway
}

func (self *Gateways) parseIPv4(str string) (net.IP, error) {
	err := errors.New("cannot parse ip")
	ipregex := regexp.MustCompile("[a-fA-F0-9]{8}")
	if ipregex.MatchString(str) == false {
		return net.IPv4zero, err
	}
	iparr, _ := hex.DecodeString(str)
	if len(iparr) != net.IPv4len {
		return net.IPv4zero, err
	}
	return net.IP(reversebytearr(iparr)), nil
}

func (self *Gateways) parseIPv6(str string) (net.IP, error) {
	err := errors.New("cannot parse ip")
	ipregex := regexp.MustCompile("[a-fA-F0-9]{32}")
	if ipregex.MatchString(str) == false {
		return net.IPv6zero, err
	}
	iparr, _ := hex.DecodeString(str)
	if len(iparr) != net.IPv6len {
		return net.IPv6zero, err
	}
	return net.IP(iparr), nil
}

func (self *Gateways) parseUInt32(str string) (uint32, error) {
	base := 10
	hexregex := regexp.MustCompile("[a-fA-F0-9]{8}")
	numberregex := regexp.MustCompile("[0-9]+")

	if hexregex.MatchString(str) {
		base = 16
	} else if numberregex.MatchString(str) {
		base = 10
	} else {
		return 0, errors.New("cannot parse number")
	}
	val, _ := strconv.ParseUint(str, base, 64)
	return uint32(val), nil
}

/*
Iface	Destination	Gateway 	Flags	RefCnt	Use	Metric	Mask		MTU	Window	IRTT
eth0	00000000	010EF388	0003	0	0	0	00000000	0	0	0
*/
func (self *Gateways) ParseV4() error {
	//  /proc/net/route
	file, err := os.Open("/tmp/route.txt")
	if err != nil {
		return err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()

		fields := strings.Fields(line)
		if len(fields) != 11 {
			continue
		}

		gateway := Gateway{IfaceName: fields[0]}
		gateway.Destination, err = self.parseIPv4(fields[1])
		if err != nil {
			continue
		}
		gateway.Gateway, err = self.parseIPv4(fields[2])
		if err != nil {
			continue
		}
		gateway.Metric, err = self.parseUInt32(fields[6])
		if err != nil {
			continue
		}

		self.Gateways = append(self.Gateways, gateway)
	}

	return nil
}

/*
00000000000000000000000000000001 80 00000000000000000000000000000000 00 00000000000000000000000000000000 00000100 00000000 00000000 00000001       lo
fe800000000000000000000000000000 40 00000000000000000000000000000000 00 00000000000000000000000000000000 00000100 00000000 00000000 00000001     eth0
00000000000000000000000000000000 00 00000000000000000000000000000000 00 00000000000000000000000000000000 ffffffff 00000001 00000149 00200200       lo
00000000000000000000000000000001 80 00000000000000000000000000000000 00 00000000000000000000000000000000 00000000 00000002 0000538b 80200001       lo
fe80000000000000ba27ebfff4e3eb64 80 00000000000000000000000000000000 00 00000000000000000000000000000000 00000000 00000001 00000000 80200001       lo
ff000000000000000000000000000000 08 00000000000000000000000000000000 00 00000000000000000000000000000000 00000100 00000001 00002e67 00000001     eth0
00000000000000000000000000000000 00 00000000000000000000000000000000 00 00000000000000000000000000000000 ffffffff 00000001 00000149 00200200       lo
*/
func (self *Gateways) ParseV6() error {
	//  /proc/net/route
	file, err := os.Open("/tmp/route6.txt")
	if err != nil {
		return err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()

		fields := strings.Fields(line)
		if len(fields) != 10 {
			continue
		}

		gateway := Gateway{IfaceName: fields[9]}

		gateway.Destination, err = self.parseIPv6(fields[0])
		if err != nil {
			continue
		}

		gateway.Gateway, err = self.parseIPv6(fields[4])
		if err != nil {
			continue
		}

		gateway.Metric, err = self.parseUInt32(fields[6])
		if err != nil {
			continue
		}

		self.Gateways = append(self.Gateways, gateway)
	}

	return nil
}

func (self *Gateways) Parse() error {
	err4 := self.ParseV4()
	err6 := self.ParseV6()
	if err4 != nil && err6 != nil {
		return err4
	}
	return nil
}

func main() {

	// /proc/net/ipv6_route

	fmt.Println("hello world")

	gateways := &Gateways{}
	err := gateways.Parse()
	if err != nil {
		panic(err)
	}

	for _, g := range gateways.Gateways {
		fmt.Println("iface:" + g.IfaceName + "   gw:" + g.Gateway.String() + "  dest:" + g.Destination.String())
		// fmt.Printf("0x%X \n", g.Metric )
	}

}
