/*
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>
*/
package utils

import (
	"errors"
	"reflect"
	"strconv"
	"strings"
)


func SetFieldFromString(self interface{}, field string, value string) error {

	if len(field) > 0 && len(value)>0 {

		field = strings.Replace(field, " ", "_", 10)

		// replace test(abc) to test_abc
		field = strings.Replace(field, "(", "_", 10)
		field = strings.Replace(field, ")", "", 10)

		// make first letter uppercase
		field = strings.ToUpper(field[0:1]) + field[1:]
		
		// replace Test_abc to TestAbc
		for {
			index := strings.Index( field, "_")
			if index==-1 {
				 break
			}
			if strings.HasSuffix(field,"_") {
				break
			}
			field = field[0:index] + strings.ToUpper(field[index+1:index+2]) + field[index+2:]
		}

		v := reflect.ValueOf(self).Elem().FieldByName(field)

		if v.IsValid() {

			//fmt.Println(field + " " + value)

			if v.Kind() == reflect.Int64 {
				var factor int64 = 1
				if strings.HasSuffix(strings.ToUpper(value), "KB") {
					factor = 1024
					value = strings.TrimSpace(value[:len(value)-3])
				} else if strings.HasSuffix(strings.ToUpper(value), "MB") {
					factor = 1024 * 1024
					value = strings.TrimSpace(value[:len(value)-3])
				}
				 
				var i int64 = 0 
				var err error
				if strings.HasPrefix(value, "0x") {
					i, err = strconv.ParseInt(value[2:], 16, 64)
				} else {
					i, err = strconv.ParseInt(value, 10, 64)
				}
				
				if err == nil {
					v.SetInt(i * factor)
				} else {
					v.SetInt(0)
				}
				
			} else if v.Kind() == reflect.Float64 {
				f, err := strconv.ParseFloat(value, 64)
				if err == nil {
					v.SetFloat(f)
				} else {
					v.SetFloat(0.0)
				}
			} else if v.Kind() == reflect.Slice {

				arr := strings.Split(value, " ")
				v.Set(reflect.MakeSlice(v.Type(), len(arr), len(arr)))
				for i, w := range arr {
					v.Index(i).Set(reflect.ValueOf(w))
				}

			} else if v.Kind() == reflect.String {
				v.SetString(value)
			}
			return nil
		}
	}
	return errors.New("invalid argument")
}
