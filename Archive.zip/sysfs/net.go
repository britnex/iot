/*
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>
*/
package procfs

import (
	//"fmt"
	"ioutil"
	"os"
)

// NetClassIface contains info from files in /sys/class/net/<iface>
// for single interface (iface).
type NetworkInterface struct {
	Name             string // Interface name
	AddrAssignType   int64  // /sys/class/net/<iface>/addr_assign_type
	AddrLen          int64  // /sys/class/net/<iface>/addr_len
	Address          string // /sys/class/net/<iface>/address
	Broadcast        string // /sys/class/net/<iface>/broadcast
	Carrier          int64  // /sys/class/net/<iface>/carrier
	CarrierChanges   int64  // /sys/class/net/<iface>/carrier_changes
	CarrierUpCount   int64  // /sys/class/net/<iface>/carrier_up_count
	CarrierDownCount int64  // /sys/class/net/<iface>/carrier_down_count
	DevID            int64  // /sys/class/net/<iface>/dev_id
	Dormant          int64  // /sys/class/net/<iface>/dormant
	Duplex           string // /sys/class/net/<iface>/duplex
	Flags            int64  // /sys/class/net/<iface>/flags
	IfAlias          string // /sys/class/net/<iface>/ifalias
	IfIndex          int64  // /sys/class/net/<iface>/ifindex
	IfLink           int64  // /sys/class/net/<iface>/iflink
	LinkMode         int64  // /sys/class/net/<iface>/link_mode
	MTU              int64  // /sys/class/net/<iface>/mtu
	NameAssignType   int64  // /sys/class/net/<iface>/name_assign_type
	NetDevGroup      int64  // /sys/class/net/<iface>/netdev_group
	OperState        string // /sys/class/net/<iface>/operstate
	PhysPortID       string // /sys/class/net/<iface>/phys_port_id
	PhysPortName     string // /sys/class/net/<iface>/phys_port_name
	PhysSwitchID     string // /sys/class/net/<iface>/phys_switch_id
	Speed            int64  // /sys/class/net/<iface>/speed
	TxQueueLen       int64  // /sys/class/net/<iface>/tx_queue_len
	Type             int64  // /sys/class/net/<iface>/type
}

type NetworkInterfaces struct {
	NetworkInterfaces []NetworkInterface
}

func (self *NetworkInterfaces) Parse(filename string) error {

	ifacedirs, err := ioutil.ReadDir("/sys/class/net/")
	if err != nil {
		return err
	}

	for _, ifacedir := range ifacedirs {
		networkinterface := &NetworkInterface{}
		self.NetworkInterfaces = append(self.NetworkInterfaces, networkinterface)

		ifacefiles, err := ioutil.ReadDir(ifacedir)
		if err != nil {
			continue
		}

		for _, ifacefile := range ifacefiles {

			f, err := os.Open(ifacefile)
			if err != nil {
				continue
			}
			defer f.Close()
			
			r := bufio.NewReader(f)
			line, err := r.ReadString('\n')

			key := ""
			val := ""
			utils.SetFieldFromString(networkinterface, key, val)

		}
	}

	return nil
}
