/*
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>
*/
package procfs

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
	"strconv"
)

type Module struct {
	Module string
	Size int64
	Used int64
}

type Modules struct {
	Modules [] Module
}

func (self *Modules) Parse(filename string) error {
	f, err := os.Open(filename)
	if err != nil {
		fmt.Println("error opening file ", err)
		return err
	}
	defer f.Close()
	r := bufio.NewReader(f)

	for {
		line, err := r.ReadString('\n')
		if err == io.EOF {
			break
		} else if err != nil {
			return err
		}
		arr := strings.Split(line, " ")
		if len(arr) >= 3 {
			
			module := arr[0]
			size, sizeerr := strconv.ParseInt(arr[1], 10, 64)
			used, usederr := strconv.ParseInt(arr[2], 10, 64)
			
			if (sizeerr==nil) && (usederr==nil) {
				self.Modules=append(self.Modules, Module{Module:module, Size:size, Used:used} )
			}
		}
	}

	return nil
}
