/*
This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <http://unlicense.org>
*/
package procfs

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
	"utils"
)

type Memory struct {
	MemTotal      int64
	MemFree       int64
	MemAvailable  int64
	Buffers       int64
	Cached        int64
	SwapCached    int64
	Active        int64
	Inactive      int64
	Active_anon   int64
	Inactive_anon int64
	Active_file   int64
	Inactive_file int64
	Unevictable   int64
	Mlocked       int64
	SwapTotal     int64
	SwapFree      int64
	Dirty         int64
	Writeback     int64
	AnonPages     int64
	Mapped        int64
	Shmem         int64
	Slab          int64
	SReclaimable  int64
	SUnreclaim    int64
	KernelStack   int64
	PageTables    int64
	NFS_Unstable  int64
	Bounce        int64
	WritebackTmp  int64
	CommitLimit   int64
	Committed_AS  int64
	VmallocTotal  int64
	VmallocUsed   int64
	VmallocChunk  int64
	CmaTotal      int64
	CmaFree       int64
}

func (self *Memory) Parse(filename string) error {
	f, err := os.Open(filename)
	if err != nil {
		fmt.Println("error opening file ", err)
		return err
	}
	defer f.Close()
	r := bufio.NewReader(f)

	for {
		line, err := r.ReadString('\n')
		if err == io.EOF {
			break
		} else if err != nil {
			return err
		}
		arr := strings.Split(line, ":")
		if len(arr) == 2 {
			key := strings.TrimSpace(arr[0])
			val := strings.TrimSpace(arr[1])
			
			utils.SetFieldFromString(self, key, val)
		}
	}

	return nil
}
